// -1: 无状态  0:加载中  1: 失败 2:成功
export enum EFlag {
  None = -1,
  Loading = 0,
  Fail = 1,
  Success = 2,
}
